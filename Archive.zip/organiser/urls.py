from django.urls import path
from . import views



app_name = 'organiser'

urlpatterns = [
    #path('create-event/', EventWizard.as_view(FORMS, TEMPLATES), name='create_event'),
    path('register/', views.organiser_registration, name='register'),
    path('dashboard/', views.organiser_dashboard, name='dashboard'),
    path('create-event/', views.create_event, name='create_event'),
    path('organiser/event-list', views.organiser_events, name='my_events'),
    path('organiser/events/<slug:slug>/', views.event_detail, name='my_event'),
    path('organiser/edit/event/<slug:event_slug>/', views.edit_event, name='event_edit'),
    path('login/', views.organiser_login, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('registration-complete/', views.registration_complete, name='registration_complete'),
    path('profile/', views.organiser_profile, name='organiser_profile'),
    path('organiser/statistics/', views.organiser_statistics, name='organiser_statistics'),
    path('banking/',views.bank_view,name='banking'),
    path('bank/details/<int:organiser_id>/', views.bank_list, name='bank_list'), 
    path('knowledge-base/', views.knowledge_base, name='knowledge_base'),
    #path('api/organiser/dashboard/', views.get_organiser_dashboard_data, name='api_dashboard'),
    #path('api/statistics/', views.get_statistics_data, name='api_statistics'), 
    path('support/', views.support, name='support'),
    path('reports/', views.organiser_sales_report_view, name='organiser_sales_report_view'),
    path('reports/<int:report_id>/download/', views.download_report_csv, name='download_report'),
    path('reports/<int:report_id>/email/', views.email_report, name='email_report'),
    path('ajax/load-subcategories/', views.load_subcategories, name='ajax_load_subcategories'),
    path('event/<slug:event_slug>/toggle-status/', views.event_toggle_status, name='event_toggle_status'),
    path('verify-email/<uidb64>/<token>/', views.verify_email, name='verify_email'),
    path('organiser/email-notice/',views.verify_email_notice,name='email_notice')



]
