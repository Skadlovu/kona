from django.contrib import admin
from .models import Organiser

class OrganiserAdmin(admin.ModelAdmin):
    list_display = ( 'user', 'approved')  # Display approval status
    list_filter = ('approved',)  # Filter by approval status
    actions = ['approve_organisers', 'disapprove_organisers']

    def approve_organisers(self, request, queryset):
        queryset.update(approved=True)
        self.message_user(request, "Selected organisers have been approved.")
    approve_organisers.short_description = "Approve selected organisers"

    def disapprove_organisers(self, request, queryset):
        queryset.update(approved=False)
        self.message_user(request, "Selected organisers have been disapproved.")
    disapprove_organisers.short_description = "Disapprove selected organisers"

admin.site.register(Organiser, OrganiserAdmin)
