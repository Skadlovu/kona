from storages.backends.gcloud import GoogleCloudStorage
from django.db import models
from organiser.models import Organiser
from django.utils.text import slugify
from django.urls import reverse
from django.db.models import Min, Max
from.create_portrait import create_portrait
from. create_landscape import create_landscape
from taggit.managers import TaggableManager
from customer.models import Customer
from django.core.exceptions import ValidationError
from PIL import Image
from ckeditor.fields import RichTextField
from django.contrib.auth.models import User
from kona.gscUtils import EventPosterStorage,PortraitStorage,LandscapeStorage, CategoryPoster

class City(models.Model):
    name=models.CharField(max_length=100)
    slug = models.SlugField(unique=True, max_length=100, blank=True, null=False)
    number_of_events = models.IntegerField(default=0)
    status = models.BooleanField(default=True)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('city', kwargs={'slug': self.slug})

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
            # Ensure the slug is unique
            original_slug = self.slug
            queryset =City.objects.filter(slug=self.slug)
            count = 1
            while queryset.exists():
                self.slug = f'{original_slug}-{count}'
                count += 1
                queryset = City.objects.filter(slug=self.slug)
        super().save(*args, **kwargs)


class Category(models.Model):
    name = models.CharField(max_length=255)
    category_poster = models.ImageField(default='red.jpg', storage=CategoryPoster())
    slug = models.SlugField(unique=True, max_length=100, blank=True, null=False)
    number_of_events = models.IntegerField(default=0)
    status = models.BooleanField(default=True)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('category', kwargs={'slug': self.slug})

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
            # Ensure the slug is unique
            original_slug = self.slug
            queryset = Category.objects.filter(slug=self.slug)
            count = 1
            while queryset.exists():
                self.slug = f'{original_slug}-{count}'
                count += 1
                queryset = Category.objects.filter(slug=self.slug)
        super().save(*args, **kwargs)


class SubCategory(models.Model):
    name = models.CharField(max_length=255)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='subcategory')
    slug = models.SlugField(unique=True, max_length=100, blank=True, null=False)
    number_of_events = models.IntegerField(default=0)
    status = models.BooleanField(default=True)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('subcategory', kwargs={'slug': self.slug})

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
            # Ensure the slug is unique
            original_slug = self.slug
            queryset = SubCategory.objects.filter(slug=self.slug)
            count = 1
            while queryset.exists():
                self.slug = f'{original_slug}-{count}'
                count += 1
                queryset = SubCategory.objects.filter(slug=self.slug)
        super().save(*args, **kwargs)


class Event(models.Model):
    title = models.CharField(max_length=255)
    description = RichTextField()
    poster = models.ImageField(
        storage=EventPosterStorage(),
        default='red.jpeg'
    )
    slug = models.SlugField(unique=True, max_length=100, blank=True, null=False)
    status = models.BooleanField(default=True)
    views = models.IntegerField(default=0)
    likes=models.ManyToManyField(User, related_name='event_likes', blank=True)
    wish_list=models.ManyToManyField(User, related_name='event_wish_list', blank=True)
    organiser = models.ForeignKey(Organiser, on_delete=models.CASCADE, related_name='events')
    date_posted = models.DateTimeField(auto_now_add=True)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, related_name='events')
    event_date = models.DateField()
    address = models.TextField(blank=True, null=True)
    google_maps_location = models.URLField(max_length=500,blank=True, null=True)
    venue = models.CharField(max_length=255)
    event_time = models.TimeField()
    approved = models.BooleanField(default=False)
    portrait = models.ImageField(
        storage=PortraitStorage(),
        blank=True,
        null=True
    )
    
    landscape = models.ImageField(
        storage=LandscapeStorage(),
        blank=True,
        null=True
    )
    tags=TaggableManager()
    attendees = models.ManyToManyField(Customer, related_name='events_attended',blank=True,)
    revenue=models.PositiveBigIntegerField(default=0)
    active=models.BooleanField(default=True)
    completed=models.BooleanField(default=False)
    cancelled=models.BooleanField(default=False)
    rating=models.FloatField(default=0.0)
    commission_amount=models.IntegerField(default=0)
    attendee_count=models.IntegerField(default=0)



    class Meta:
        ordering = ['-date_posted']  # Orders events by date_posted, latest first

    def __str__(self):
        return self.title

    def number_of_likes(self):
        return self.likes.count

    def number_of_wishers(self):
        return self.wish_list.count

    def get_absolute_url(self):
        return reverse('event:detail', kwargs={'slug': self.slug})

    def save(self, *args, **kwargs):
        # Generate a unique slug if it's missing
        if not self.slug:
            self.slug = self.generate_unique_slug()

        super().save(*args, **kwargs)  # Save event first to make image file accessible

        # Create landscape and portrait images
        create_landscape(self)
        create_portrait(self)

    def generate_unique_slug(self):
        """Generates a unique slug based on the event title."""
        base_slug = slugify(self.title)
        slug = base_slug
        count = 1
        while Event.objects.filter(slug=slug).exists():
            slug = f'{base_slug}-{count}'
            count += 1
        return slug

    def lowest_price(self):
        """Returns the lowest ticket price for this event."""
        return self.ticket_details.aggregate(lowest_price=Min('price'))['lowest_price']

    def highest_price(self):
        """Returns the highest ticket price for this event."""
        return self.ticket_details.aggregate(highest_price=Max('price'))['highest_price']





class Performer(models.Model):
    event=models.ForeignKey(Event,on_delete=models.CASCADE, related_name='performers')
    entertainer=models.CharField(max_length=100)

    def __str__(self):
        return f"{self.entertainer}- {self.event.title}"


class EventView(models.Model):
    sesID = models.CharField(verbose_name='session ID', max_length=150, db_index=True)
    eventSlug = models.ForeignKey(Event, blank=True, null=True, default=None, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    created_at=models.DateTimeField(auto_now_add=True, blank=True, null=True)

    def __str__(self):
        return '{} - {}'.format(self.sesID, self.eventSlug)



