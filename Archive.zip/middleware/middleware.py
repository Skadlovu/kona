from django.urls import resolve
from django.shortcuts import redirect
from django.contrib import messages
from django.conf import settings
from django.core.exceptions import PermissionDenied

class OrganiserAccessMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        try:
            # Early return for excluded paths (like static files, admin, etc.)
            if any(request.path.startswith(path) for path in getattr(settings, 'MIDDLEWARE_EXEMPT_PATHS', ['/static/', '/media/', '/admin/'])):
                return self.get_response(request)

            # Get current URL information early to handle invalid URLs
            try:
                resolved = resolve(request.path_info)
                current_namespace = resolved.namespace
                current_url_name = resolved.url_name
            except:
                # Handle invalid URLs appropriately
                return self.get_response(request)

            # Check if user is authenticated
            if not request.user.is_authenticated:
                return self.get_response(request)

            # Specific checks for organiser users
            if hasattr(request.user, 'organiser'):
                organiser = request.user.organiser

                # Define allowed public namespaces
                public_namespaces = {'public', 'auth', 'accounts'}

                # Check namespace restrictions
                if current_namespace not in public_namespaces and current_namespace != 'organiser':
                    messages.error(request, 'Access restricted to organiser pages only.')
                    return redirect('organiser:dashboard')

                # Profile completion check
                if not organiser.is_profile_complete:
                    allowed_urls = {
                        'organiser:organiser_profile',
                        'organiser:banking',
                        'organiser:logout',
                        'organiser:password_change'
                    }

                    if f"{current_namespace}:{current_url_name}" not in allowed_urls:
                        messages.warning(request, 'Please complete your profile and banking information first.')
                        return redirect('organiser:organiser_profile')

                # Add additional security checks here if needed
                # For example, checking if the organiser is active
                if not getattr(organiser, 'is_active', True):
                    raise PermissionDenied('Your organiser account is currently inactive.')

            return self.get_response(request)

        except Exception as e:
            # Log the error appropriately
            if settings.DEBUG:
                raise e
            messages.error(request, 'An error occurred. Please try again.')
            return redirect('organiser:dashboard')



class CustomerAccessMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        try:
            # Skip middleware for static/media files
            if any(request.path.startswith(path) for path in ['/static/', '/media/', '/admin/']):
                return self.get_response(request)

            # Only check authenticated users
            if request.user.is_authenticated:
                try:
                    resolved = resolve(request.path_info)
                    current_namespace = resolved.namespace
                    current_url_name = resolved.url_name
                except:
                    return self.get_response(request)

                # Check if user is a customer (not an organiser)
                # Assuming customer users have a related 'customer' model
                if hasattr(request.user, 'customer') and not hasattr(request.user, 'organiser'):
                    # Block access to organiser namespace
                    if current_namespace == 'organiser':
                        messages.error(
                            request,
                            'Access denied. This area is restricted to organisers only.'
                        )
                        # Redirect to customer dashboard or appropriate page
                        return redirect('customer:dashboard')  # Adjust this to your URL name

            return self.get_response(request)

        except Exception as e:
            if settings.DEBUG:
                raise e
            messages.error(request, 'An error occurred. Please try again.')
            return redirect('home')  # Adjust this to your home URL name