from cart.models import Cart
from event.models import Category


def categories(request):
    categories = Category.objects.filter(status=True).order_by('name')
    return {'event_categories': categories}




def cart_item_count(request):
    cart_count = 0
    if request.user.is_authenticated:
        cart = Cart.objects.filter(user=request.user).first()
    else:
        cart = Cart.objects.filter(session_key=request.session.session_key).first()

    if cart:
        cart_count = cart.cart_item_count()

    return {'cart_item_count': cart_count}
