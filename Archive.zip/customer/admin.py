from django.contrib import admin
from.models import Customer,CustomerReward

class CustomerAdmin(admin.ModelAdmin):
    list_display = ( 'user', 'verified')  # Display approval status

class CustomerRewardAdmin(admin.ModelAdmin):
    list_display=('customer', 'points','lifetime_points') 

admin.site.register(Customer, CustomerAdmin)

admin.site.register(CustomerReward,CustomerRewardAdmin)