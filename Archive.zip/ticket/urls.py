from django.urls import path
from . import views

app_name = 'ticket'

urlpatterns = [
    path('buy/<int:event_id>/', views.buy_tickets, name='buy'),
   
]
