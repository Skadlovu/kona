from django.db import models
from django.contrib.auth.models import User
from event.models import Event
from django.core.validators import RegexValidator
from django.utils import timezone
from organiser.models import Organiser
from customer.models import Customer



class TicketDetails(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='ticket_details')
    class_name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    number_of_tickets = models.IntegerField()

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        availability, created = TicketAvailability.objects.get_or_create(
            ticket_details=self,
            defaults={'quantity': self.number_of_tickets, 'available': True}
        )
        if not created:
            availability.quantity = self.number_of_tickets
            availability.available = availability.tickets_remaining > 0  # Now a property
            availability.save()

    @property
    def tickets_remaining(self):
        # Since it should be OneToOne, we can use hasattr instead of first()
        if hasattr(self, 'availability'):
            return self.availability.tickets_remaining  # Now a property
        return 0

    @property
    def tickets_sold(self):
        if hasattr(self, 'availability'):
            return self.availability.sold
        return 0


class TicketAvailability(models.Model):
    ticket_details = models.OneToOneField(TicketDetails, on_delete=models.CASCADE, related_name='availability')
    quantity = models.PositiveIntegerField()
    sold = models.PositiveIntegerField(default=0)
    available = models.BooleanField(default=True)

    @property
    def tickets_remaining(self):
        return max(0, self.quantity - self.sold)
    
    def update_tickets_sold(self, quantity):
        self.sold += quantity
        self.available = self.tickets_remaining > 0
        self.save()

class TicketSales(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    organiser = models.ForeignKey(Organiser, on_delete=models.SET_NULL, null=True, blank=True) 
    purchase_date = models.DateTimeField(auto_now_add=True)
    total_price = models.DecimalField(max_digits=10, decimal_places=2)
    event = models.ForeignKey(Event, on_delete=models.CASCADE,blank=True, null=True)

    class Meta:
        ordering = ['purchase_date']
   
    
    def __str__(self):
        return f"Ticket Sale by {self.customer.username} on {self.purchase_date}"


class TicketHolder(models.Model):
    ticket_sales = models.ForeignKey(TicketSales, on_delete=models.CASCADE, related_name='ticket_holders' ,blank=True, null=True)
    ticket_details = models.ForeignKey(TicketDetails, on_delete=models.CASCADE, related_name='ticket_info')
    name = models.CharField(max_length=255)
    surname = models.CharField(max_length=255)
    ticket_date = models.DateTimeField(auto_now_add=True)
    identity_number=models.CharField(max_length=13, validators=[
        RegexValidator(
            regex=r'^\+?1?\d{9,13}$',
            message="South African Identity Number."
        )
    ] )
    price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    
    def __str__(self):
        return f"{self.name} {self.surname} - {self.ticket_details.event.title}"
    


class Ticket(models.Model):
    id=models.AutoField(primary_key=True)
    ticket_holder = models.ForeignKey(TicketHolder, on_delete=models.CASCADE)
    
    # Other fields for tickets



class TicketCancellation(models.Model):
    ticket_holder = models.OneToOneField(TicketHolder, on_delete=models.CASCADE)
    cancelled_at = models.DateTimeField(default=timezone.now)
    refund_amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    reason = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Cancellation of {self.ticket_holder.name} for {self.ticket_holder.ticket_details.event.title}"