import requests
from django.conf import settings
from django.urls import reverse
import hashlib
import time 
import urllib.parse
from django.core.exceptions import ValidationError
import logging
import datetime
from textblob import TextBlob



logger = logging.getLogger(__name__)

def process_payfast_payment(event, customer, total_amount):
    # PayFast API endpoint (use sandbox for testing)
    payfast_url = 'https://sandbox.payfast.co.za/eng/process'
    
    # Generate a unique payment identifier
    payment_id = f"ticket_{event.id}_{customer.id}_{int(time.time())}"
    
    # Construct the return and notify URLs
    base_url = settings.BASE_URL  # You need to set this in your Django settings
    return_url = 'http://127.0.0.1:8000/return'
    cancel_url = 'http://127.0.0.1:8000/cancel'
    notify_url = 'http://127.0.0.1/notify'
    
    # Prepare the payment data
    payment_data = {
        'merchant_id': settings.PAYFAST_MERCHANT_ID,
        'merchant_key': settings.PAYFAST_MERCHANT_KEY,
        'amount': f"{total_amount:.2f}",  # Use the total_amount passed to the function
        'item_name': f"Ticket for {event.title}",
        'return_url': return_url,
        'cancel_url': cancel_url,
        'notify_url': notify_url,
        'email_address': customer.user.email,
        'm_payment_id': payment_id,
    }
    
    # Generate signature
    signature = generate_payfast_signature(payment_data, settings.PAYFAST_PASSPHRASE)
    payment_data['signature'] = signature
    
    try:
        # Send request to PayFast
        response = requests.post(payfast_url, data=payment_data)
        
        if response.status_code == 200:
            # PayFast typically responds with a redirect URL
            redirect_url = response.url
            return {
                'success': True,
                'redirect_url': redirect_url,
                'payment_id': payment_id
            }
        else:
            return {
                'success': False,
                'error': f"PayFast returned status code {response.status_code}"
            }
    except requests.RequestException as e:
        return {
            'success': False,
            'error': f"Failed to connect to PayFast: {str(e)}"
        }

def generate_payfast_signature(data, passphrase=''):
    # Sort the data by key (alphabetically)
    sorted_data = {k: v for k, v in sorted(data.items())}
    
    # Concatenate the data into a query string format (key=value&key=value...)
    query_string = urllib.parse.urlencode(sorted_data)
    
    # If a passphrase is provided, append it to the query string
    if passphrase:
        query_string += f"&passphrase={passphrase}"
    
    # Generate the signature by hashing the query string using MD5
    signature = hashlib.md5(query_string.encode('utf-8')).hexdigest()
    
    return signature

def setup_payfast_recurring_payment(ticket):
    payfast_url = 'https://sandbox.payfast.co.za/eng/process'  # Use the sandbox URL for testing
    
    payload = {
        'merchant_id': 'YOUR_MERCHANT_ID',
        'merchant_key': 'YOUR_MERCHANT_KEY',
        'return_url': 'http://yoursite.com/return',
        'cancel_url': 'http://yoursite.com/cancel',
        'notify_url': 'http://yoursite.com/notify',
        'amount': str(ticket.event.price / ticket.credit_duration),
        'item_name': f'Ticket for {ticket.event.name}',
        'subscription_type': '1',  # Recurring billing
        'frequency': '3',  # Monthly
        'cycles': str(ticket.credit_duration),
    }
    
    response = requests.post(payfast_url, data=payload)
    
    # Process the response and return appropriate result
    if response.status_code == 200:
        return {'success': True}
    else:
        return {'success': False}
    



# Financial Analysis Functions

def calculate_dti(income, expenses):
    """
    Calculate the Debt-to-Income (DTI) ratio.
    DTI = Total Debts / Gross Income
    """
    return round(expenses / income, 2)

def calculate_financial_score(income, expenses):
    """
    Calculate the financial score based on DTI and other metrics.
    A lower DTI indicates better financial health.
    """
    dti = calculate_dti(income, expenses)
    if dti < 0.36:
        return 100  # High creditworthiness
    elif 0.36 <= dti < 0.5:
        return 75  # Medium creditworthiness
    else:
        return 50  # Low creditworthiness

# Social Media Analysis Functions

def analyze_sentiment(post_text):
    """
    Analyze the sentiment of a social media post.
    Returns a sentiment score between -1 (negative) and 1 (positive).
    """
    analysis = TextBlob(post_text)
    return analysis.sentiment.polarity

def fetch_social_media_data(user):
    """
    Fetch social media data for a user.
    Example: You might use the Twitter API, Facebook API, etc.
    """
    # Example: Fetching from a hypothetical API
    response = requests.get(f"https://socialmediaapi.com/user/{user.username}/posts", 
                            headers={'Authorization': f'Bearer {settings.SOCIAL_MEDIA_API_KEY}'})
    if response.status_code == 200:
        return response.json()
    else:
        return []

def calculate_social_media_score(social_media_posts):
    """
    Calculate the social media score based on sentiment and engagement metrics.
    """
    total_sentiment = 0
    total_posts = len(social_media_posts)
    
    for post in social_media_posts:
        sentiment = analyze_sentiment(post['text'])
        total_sentiment += sentiment
    
    if total_posts > 0:
        average_sentiment = total_sentiment / total_posts
        return round((average_sentiment + 1) * 50, 2)  # Normalize to a score out of 100
    else:
        return 50  # Neutral score if no posts are available

# Combined Creditworthiness Score

def calculate_creditworthiness_score(income, expenses, social_media_posts):
    """
    Combine financial and social media analysis to generate a final creditworthiness score.
    """
    financial_score = calculate_financial_score(income, expenses)
    social_media_score = calculate_social_media_score(social_media_posts)
    
    final_score = (financial_score * 0.75) + (social_media_score * 0.25)
    return round(final_score, 2)

# Storing Data for 3 Months

def store_creditworthiness_score(user, income, expenses, social_media_posts):
    """
    Store the calculated creditworthiness score with a timestamp in the database.
    """
    from .models import CreditworthinessScore

    score = calculate_creditworthiness_score(income, expenses, social_media_posts)
    CreditworthinessScore.objects.create(
        user=user,
        income=income,
        expenses=expenses,
        financial_score=calculate_financial_score(income, expenses),
        social_media_score=calculate_social_media_score(social_media_posts),
        final_score=score,
        date_assessed=datetime.datetime.now()
    )
    return score

def reassess_creditworthiness(user):
    """
    Reassess the user's creditworthiness if more than 3 months have passed.
    """
    from .models import CreditworthinessScore
    three_months_ago = datetime.datetime.now() - datetime.timedelta(days=90)
    recent_assessment = CreditworthinessScore.objects.filter(user=user, date_assessed__gte=three_months_ago).first()
    
    if not recent_assessment:
        # Prompt the user to update their financial and social media info
        return "Please update your financial and social media information for reassessment."
    else:
        return recent_assessment.final_score



def validate_ticketholder_info(request, cart_items):
    """
    Validate ticket holder information from POST request
    
    Args:
        request: The HTTP request object
        cart_items: QuerySet of CartItem objects
    
    Returns:
        bool: True if validation passes
    
    Raises:
        ValidationError: If validation fails
    """
    ticketholders = []
    
    for item in cart_items:
        if not item.ticket_details.requires_holder_info:
            continue
            
        for i in range(item.quantity):
            prefix = f'ticket_{item.ticket_details.id}'
            name = request.POST.get(f'{prefix}_name_{i}', '').strip()
            surname = request.POST.get(f'{prefix}_surname_{i}', '').strip()
            
            # Basic validation
            if not name or len(name) < 2:
                raise ValidationError(f"Invalid name for ticket {i+1}")
                
            if not surname or len(surname) < 2:
                raise ValidationError(f"Invalid surname for ticket {i+1}")
                
                
            ticketholders.append({
                'ticket_details_id': item.ticket_details.id,
                'name': name,
                'surname': surname,
              
            })
    
    # Store validated data in request for later use
    request.validated_ticketholders = ticketholders
    return True

def store_ticketholder_info(request):
    """
    Store validated ticket holder information in session
    
    Args:
        request: The HTTP request object containing validated_ticketholders
    """
    if not hasattr(request, 'validated_ticketholders'):
        raise ValidationError("No validated ticket holder information found")
        
    request.session['ticketholders'] = request.validated_ticketholders
    request.session.modified = True