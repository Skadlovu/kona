import uuid
from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from decimal import Decimal
from ticket.models import TicketDetails,TicketHolder,TicketSales

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="cart", null=True, blank=True)
    session_key = models.CharField(max_length=40, unique=True, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['user'],
                condition=models.Q(user__isnull=False),
                name='unique_user_cart'
            ),
            models.UniqueConstraint(
                fields=['session_key'],
                condition=models.Q(session_key__isnull=False),
                name='unique_session_cart'
            )
        ]

    def __str__(self):
        return f"Cart for {self.user.username if self.user else 'Anonymous'}"
    
    
    def cart_item_count(self):
        return self.items.aggregate(total=models.Sum('quantity'))['total'] or 0

    @property
    def total_price(self):
        return sum(item.total_price for item in self.items.all())

    @classmethod
    def get_cart(cls, request):
        if request.user.is_authenticated:
            cart, _ = cls.objects.get_or_create(user=request.user)
            if request.session.session_key:
                # Migrate any items from session cart to user cart
                session_cart = cls.objects.filter(session_key=request.session.session_key).first()
                if session_cart:
                    session_cart.items.update(cart=cart)
                    session_cart.delete()
            return cart
        else:
            if not request.session.session_key:
                request.session.create()
            return cls.objects.get_or_create(session_key=request.session.session_key)[0]

    def checkout(self, ticketholders):
        """
        Process checkout with individual ticketholder information
        """
        if not self.items.exists():
            return None

        sale = TicketSales.objects.create(
            customer=self.user.customer if self.user else None,
            total_price=self.total_price
        )
        
        for item in self.items.all():
            item_holders = [h for h in ticketholders if h['ticket_id'] == item.ticket_details.id]
            
            for holder in item_holders:
                TicketHolder.objects.create(
                    ticket_sales=sale,
                    ticket_details=item.ticket_details,
                    name=holder['name'],
                    surname=holder['surname'],
                    price=item.ticket_details.price
                )
                
            item.ticket_details.update_availability(-item.quantity)
        
        self.items.all().delete()
        return sale

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name="items")
    ticket_details = models.ForeignKey(TicketDetails, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    
    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['cart', 'ticket_details'],
                name='unique_cart_ticket'
            )
        ]

    @property
    def total_price(self):
        return Decimal(str(self.quantity)) * self.ticket_details.price

    def __str__(self):
        return f"{self.quantity} x {self.ticket_details.class_name}"