from django.shortcuts import render
from django.http import JsonResponse
from cart.models import Cart
from django.contrib.sessions.models import Session


def cart_item_count_view(request):
    cart_count = 0
    if request.user.is_authenticated:
        cart = Cart.objects.filter(user=request.user).first()
    else:
        cart = Cart.objects.filter(session_key=request.session.session_key).first()

    if cart:
        cart_count = cart.cart_item_count()

    return JsonResponse({'cart_item_count': cart_count})


def about(request):
    return render(request, 'about.html')

def terms(request):
    return render(request, 'terms.html')


def privacy(request):
    return render(request, 'privacy.html')


def ticket_agreement(request):
    return render(request, 'ticket_agreement.html')


def disclaimer(request):
    return render(request, 'disclaimer.html')